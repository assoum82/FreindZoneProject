package test;

public class Personne {
String nom;
String nationalit�;


public Personne(String a, String b) {
	// TODO Auto-generated constructor stub
	nom = a ;
	nationalit� = b;
}

}
