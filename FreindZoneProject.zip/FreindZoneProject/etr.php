<?php

if(isset($_POST['search']))
{
    $valueToSearch = 'Algerie';
    $query = "SELECT * FROM `amis` WHERE NOT CONCAT(`Pays`) LIKE '%".$valueToSearch."%'";
    $search_result = filterTable($query);
    
}
 else {
    $query = "SELECT * FROM `Pays`";
    $search_result = filterTable($query);
}

function filterTable($query)
{
    $connect = mysqli_connect("localhost", "root", "", "amis");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
     <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<title>FreindZone</title>
</head>
<style>
    
     .nav-tabs li a {
      color: #777;
  }
  #googleMap {
      width: 100%;
      height: 400px;
      -webkit-filter: grayscale(100%);
      filter: grayscale(100%);
  }  
  .navbar {
      font-family: Montserrat, sans-serif;
      margin-bottom: 0;
      background-color: #2d2d30;
      border: 0;
      font-size: 11px !important;
      letter-spacing: 4px;
      opacity: 0.9;
  }
  .navbar li a, .navbar .navbar-brand { 
      color: #d5d5d5 !important;
  }
  .navbar-nav li a:hover {
      color: #fff !important;
  }
  .navbar-nav li.active a {
      color: #fff !important;
      background-color: #29292c !important;
  }
  .navbar-default .navbar-toggle {
      border-color: transparent;
  }

    
    
    </style>
<body>
    
   <nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#myPage">FreindZone</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="Add.php">Ajouter Ami(e)</a></li>
        <li><a href="index.php">Liste Amis</a></li>
          <li><a href="search.php">Chercher</a></li>
           <li><a href="alg.php">Algeriens</a></li>
           <li><a href="etr.php">Etrangets</a></li>
      </ul>
    </div>
  </div>
</nav>
  <br> <br> <br> <br> <br> <br> <br> <br>
    <center>
<form  method="post">
            <input type="submit" class="btn btn-success" name="search" value="Afficher Amis Etrangets"><br><br>
            
            <table class="table table-striped" style="width:300px;">
    <thead style="background-color:#46C7C7;">
        <th>Nom</th>
        <th>Pays</th>
                </thead>
                <tbody>
                <?php while($row = mysqli_fetch_array($search_result)):?>
                <tr>
                    <td><?php echo $row['Nom'];?></td>
                    <td><?php echo $row['Pays'];?></td>
          
                </tr>
                <?php endwhile;?>
                    </tbody>
            </table>
        </form>
        <br><br>
    </center>
    </body>
</html>