<?php
require("db.php");
$id =$_REQUEST['AmiID'];

$result = mysql_query("SELECT * FROM amis WHERE AmiID  = '$id'");
$test = mysql_fetch_array($result);
if (!$result) 
		{
		die("Error: Data not found..");
		}
				$Nom=$test['Nom'] ;
				$Pays= $test['Pays'] ;					
			

if(isset($_POST['save']))
{	
	$Nom_save = $_POST['Nom'];
	$Pays_save = $_POST['Pays'];


	mysql_query("UPDATE amis SET Nom ='$Nom_save', Pays ='$Pays_save' WHERE AmiID = '$id'")
				or die(mysql_error()); 
	echo "Saved!";
	
	header("Location: index.php");			
}
mysql_close($conn);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
     <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<title>FreindZone</title>
</head>
<style>
    
     .nav-tabs li a {
      color: #777;
  }
  #googleMap {
      width: 100%;
      height: 400px;
      -webkit-filter: grayscale(100%);
      filter: grayscale(100%);
  }  
  .navbar {
      font-family: Montserrat, sans-serif;
      margin-bottom: 0;
      background-color: #2d2d30;
      border: 0;
      font-size: 11px !important;
      letter-spacing: 4px;
      opacity: 0.9;
  }
  .navbar li a, .navbar .navbar-brand { 
      color: #d5d5d5 !important;
  }
  .navbar-nav li a:hover {
      color: #fff !important;
  }
  .navbar-nav li.active a {
      color: #fff !important;
      background-color: #29292c !important;
  }
  .navbar-default .navbar-toggle {
      border-color: transparent;
  }

    
    
    </style>
<body>
    
   <nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#myPage">FreindZone</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="Add.php">Ajouter Ami(e)</a></li>
        <li><a href="index.php">Liste Amis</a></li>
          <li><a href="search.php">Chercher</a></li>
                <li><a href="alg.php">Algeriens</a></li>
           <li><a href="etr.php">Etrangets</a></li>
      </ul>
    </div>
  </div>
</nav>

    <br> <br> <br> <br> <br> <br> <br> <br>
    <center>
<form method="post">
<table class="table table-striped" style="width:300px;">
    <thead style="background-color:#46C7C7;">
    </thead>
    <tbody>
	<tr>
		<td>Nom:</td>
		<td><input type="text" name="Nom" value="<?php echo $Nom ?>"/></td>
	</tr>
	<tr>
		<td>Pays</td>
		<td><input type="text" name="Pays" value="<?php echo $Pays ?>"/></td>
	</tr>
	
	<tr>
		<td>&nbsp;</td>
		<td><input type="submit" class="btn btn-success" name="save" value="save" /></td>
	</tr>
        </tbody>
</table>

</body>
</html>
